#ifndef GLWIDGET_H
#define GLWIDGET_H

#include <QGLWidget>

class GLWidget : public QGLWidget
{
    Q_OBJECT
public:
    explicit GLWidget(QWidget *parent = 0);

    void initializeGL() override;
    void paintGL() override;
    void resizeGL(int w, int h) override;
private:
    float scaleFactorX, scaleFactorY; // коэффиценты для пересчета координат при изменении размера окна
};

#endif // GLWIDGET_H
