#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    // подключение кнопок к соответствующим функциям
    connect(ui->rotateLeftButton, &QPushButton::released, this, &MainWindow::rotateLeft);
    connect(ui->rotateRightButton, &QPushButton::released, this, &MainWindow::rotateRight);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::rotateRight()
{
    ui->GLwidget->rotateRight();
}

void MainWindow::rotateLeft()
{
    ui->GLwidget->rotateLeft();
}

