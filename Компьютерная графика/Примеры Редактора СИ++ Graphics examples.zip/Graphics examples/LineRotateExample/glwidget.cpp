#include "glwidget.h"
#define _USE_MATH_DEFINES
#include "math.h"



GLWidget::GLWidget(QWidget *parent):
    QGLWidget(parent)
{
    angle = 0; // определение начального значения угла
}

void GLWidget::initializeGL() // Метод, отвечающий за инициализацию виджета
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 600, 600, 0, 0, 1); // выставление размера отрисовываесого виджета
}

void GLWidget::resizeGL(int w, int h) // Метод, отвечающий за изменение размера виджета
{
    glViewport(0, 0, w, h);
    // считаем коэффиценты для пересчета координат точкек
    scaleFactorX = 600 / float(w);
    scaleFactorY = 600 / float(h);
    updateGL();
}


void GLWidget::paintGL() // Метод, отвечающий за отрисовку в виджете
{
    qglClearColor(Qt::white); // очистка виджета с помощью белого цвета
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT ); // очистка буферов
    qglColor(Qt::black); // выставление нужного цвета для отрисовки. В данном случае черного
    glLineWidth(2); // Изменение ширины линий
    float x1 = 100, y1 = 500, x2 = 500, y2 = 500, center_x, center_y; // определение начальных координат линии
    center_x = (x2 + x1) / 2; center_y = (y2 + y1) / 2; // нахождение координат центра линии
    // определение координат после поворота
    float new_x1 = center_x + (x1 - center_x) * cos(angle) - (y1 - center_y) * sin(angle);
    float new_y1 = center_x + (x1 - center_x) * sin(angle) + (y1 - center_y) * cos(angle);
    float new_x2 = center_x + (x2 - center_x) * cos(angle) - (y2 - center_y) * sin(angle);
    float new_y2 = center_x + (x2 - center_x) * sin(angle) + (y2 - center_y) * cos(angle);
    glBegin(GL_LINES); // начало создания линий
    glVertex2f(new_x1 * scaleFactorX, new_y1 * scaleFactorY); // координаты первой точки линии
    glVertex2f(new_x2 * scaleFactorX, new_y2 * scaleFactorY); // координаты второй точки линии
    glEnd(); // конец создания линий
}

void GLWidget::rotateRight()
{
    angle += M_PI / 16; // изменение угла
    updateGL(); // перерисовка линии
}

void GLWidget::rotateLeft()
{
    angle -= M_PI / 16; // изменение угла
    updateGL(); // перерисовка линии
}
