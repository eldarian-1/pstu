#include "glwidget.h"
#include "math.h"
#include <algorithm>
#include <QMouseEvent>


GLWidget::GLWidget(QWidget *parent):
    QGLWidget(parent)
{
    color = Qt::black;
    x1 = 50, y1 = 50, x2 = 500, y2 = 500;
    scaleFactorX = 1;
    scaleFactorY = 1;
}

void GLWidget::initializeGL() // Метод, отвечающий за инициализацию виджета
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 600, 600, 0, 0, 1); // выставление размера отрисовываесого виджета
}

void GLWidget::resizeGL(int w, int h) // Метод, отвечающий за изменение размера виджета
{
    glViewport(0, 0, w, h);
    // считаем коэффиценты для пересчета координат точкек
    scaleFactorX = 600 / float(w);
    scaleFactorY = 600 / float(h);
    updateGL();
}


void GLWidget::paintGL() // Метод, отвечающий за отрисовку в виджете
{
    qglClearColor(Qt::white); // очистка виджета с помощью белого цвета
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT ); // очистка буферов
    qglColor(color); // выставление нужного цвета для отрисовки. В данном случае черного
    glLineWidth(2); // Изменение ширины линий
    glBegin(GL_LINES); // начало создания линий
    glVertex2f(x1 * scaleFactorX, y1 * scaleFactorY);
    glVertex2f(x2 * scaleFactorX, y2 * scaleFactorY);
    glEnd(); // конец создания линий
}

void GLWidget::mousePressEvent(QMouseEvent* event)
{
    float mouse_x = event->pos().x(), mouse_y = event->pos().y();
    // найдем координаты верхней левой и нижней правой точек прямоугольника, диагональю которого является данная линия
    float par_x1 = std::min(x1, x2);
    float par_y1 = std::min(y1, y2);
    float par_x2 = std::max(x1, x2);
    float par_y2 = std::max(y1, y2);
    // проверим находится ли курсор мышки в данном прямоугольнике
    if (mouse_x > par_x1 && mouse_x < par_x2 && mouse_y > par_y1 && mouse_y < par_y2)
    {
        // найдем коэффиценты уравнения прямой, на которой лежит линия
        float k = (y2 - y1) / (x2 - x1);
        float b = y1 - k * x1;
        // проверим находится ли курсор на данной прямой
        if (abs(k * mouse_x + b - mouse_y) < 4) // 4 - точность, с которой мы будем определять пересечение
        {
            color = Qt::gray;
        } else
        {
            color = Qt::black;
        }
    } else
    {
        color = Qt::black;
    }
    updateGL();
}
