#ifndef GLWIDGET_H
#define GLWIDGET_H

#include <QGLWidget>
#include <vector>

struct Line { // структура для хранения данных о линии
    float x1, x2, y1, y2; // координаты точек линии
};

class GLWidget : public QGLWidget
{
    Q_OBJECT
public:
    explicit GLWidget(QWidget *parent = 0);

    void initializeGL() override;
    void paintGL() override;
    void resizeGL(int w, int h) override;
    void addLine(float x1, float y1, float x2, float y2); // метод добавления линии
private:
    float scaleFactorX, scaleFactorY; // коэффиценты для пересчета координат при изменении размера окна
    std::vector<Line> lines; // поле для хранения созданных линий
};

#endif // GLWIDGET_H
