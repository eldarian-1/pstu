#include "glwidget.h"

GLWidget::GLWidget(QWidget *parent):
    QGLWidget(parent)
{

}

void GLWidget::initializeGL() // Метод, отвечающий за инициализацию виджета
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 600, 600, 0, 0, 1); // выставление размера отрисовываесого виджета
}

void GLWidget::resizeGL(int w, int h) // Метод, отвечающий за изменение размера виджета
{
    glViewport(0, 0, w, h);
    // считаем коэффиценты для пересчета координат точкек
    scaleFactorX = 600 / float(w);
    scaleFactorY = 600 / float(h);
    updateGL();
}

void GLWidget::paintGL() // Метод, отвечающий за отрисовку в виджете
{
    qglClearColor(Qt::white); // очистка виджета с помощью белого цвета
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT ); // очистка буферов
    qglColor(Qt::black); // выставление нужного цвета для отрисовки. В данном случае черного
    glLineWidth(2); // Изменение ширины линий
    glBegin(GL_LINES); // начало создания линий
    glVertex2f(50 * scaleFactorX, 50 * scaleFactorY); // координаты первой точки первой линии
    glVertex2f(550 * scaleFactorX, 550 * scaleFactorY); // координаты второй точки первой линии
    glVertex2f(400 * scaleFactorX, 50 * scaleFactorY); // координаты первой точки второй линии
    glVertex2f(50 * scaleFactorX, 400 * scaleFactorY); // координаты второй точки второй линии
    glEnd(); // конец создания линий
}
