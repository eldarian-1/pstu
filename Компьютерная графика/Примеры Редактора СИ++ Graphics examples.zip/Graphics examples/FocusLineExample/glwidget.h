#ifndef GLWIDGET_H
#define GLWIDGET_H

#include <QGLWidget>
#include <vector>


class GLWidget : public QGLWidget
{
    Q_OBJECT
public:
    explicit GLWidget(QWidget *parent = 0);

    void initializeGL() override;
    void paintGL() override;
    void resizeGL(int w, int h) override;

private slots:
    void mousePressEvent(QMouseEvent* event) override; // перегрузка метода оброботки нажатия мыши

private:
    QColor color; // цвет линии
    float x1, y1, x2, y2; // кооридинаты точек линии
    float scaleFactorX, scaleFactorY; // коэффиценты для пересчета координат при изменении размера окна
};

#endif // GLWIDGET_H
