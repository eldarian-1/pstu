#ifndef GLWIDGET_H
#define GLWIDGET_H

#include <QGLWidget>

class GLWidget : public QGLWidget
{
    Q_OBJECT
public:
    explicit GLWidget(QWidget *parent = 0);

    void initializeGL() override;
    void paintGL() override;
    void resizeGL(int w, int h) override;
    void rotateRight();
    void rotateLeft();
private:
    float scaleFactorX, scaleFactorY; // коэффиценты для пересчета координат при изменении размера окна
    float angle; // поле для хранения текущего угла поворота
};

#endif // GLWIDGET_H
