#include "glwidget.h"
#include "math.h"

GLWidget::GLWidget(QWidget *parent):
    QGLWidget(parent)
{

}

void GLWidget::initializeGL() // Метод, отвечающий за инициализацию виджета
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 600, 600, 0, 0, 1); // выставление размера отрисовываесого виджета
}

void GLWidget::resizeGL(int w, int h) // Метод, отвечающий за изменение размера виджета
{
    glViewport(0, 0, w, h);
    // считаем коэффиценты для пересчета координат точкек
    scaleFactorX = 600 / float(w);
    scaleFactorY = 600 / float(h);
    updateGL();
}


void GLWidget::paintGL() // Метод, отвечающий за отрисовку в виджете
{
    qglClearColor(Qt::white); // очистка виджета с помощью белого цвета
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT ); // очистка буферов
    qglColor(Qt::black); // выставление нужного цвета для отрисовки. В данном случае черного
    glLineWidth(2); // Изменение ширины линий
    glBegin(GL_LINES); // начало создания линий
    for (int i = 0; i < lines.size(); ++i) // цикл прохода по всем элементам списка линий
    {
        // отрисовка i-ой линии
        glVertex2f(lines[i].x1 * scaleFactorX, lines[i].y1 * scaleFactorY);
        glVertex2f(lines[i].x2 * scaleFactorX, lines[i].y2 * scaleFactorY);
    }
    glEnd(); // конец создания линий
}

void GLWidget::addLine(float x1, float y1, float x2, float y2)
{
    Line new_line; // создание указателя на новую линию
    // определение координат линии
    new_line.x1 = x1;
    new_line.y1 = y1;
    new_line.x2 = x2;
    new_line.y2 = y2;
    lines.push_back(new_line); // добавление линии
    updateGL(); // перерисовка линий
}
