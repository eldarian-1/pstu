#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
     connect(ui->createLineButton, &QPushButton::released, this, &MainWindow::addLine);
}

void MainWindow::addLine()
{
   ui->GLwidget->addLine(ui->lineX1->text().toFloat(),
                         ui->lineY1->text().toFloat(),
                         ui->lineX2->text().toFloat(),
                         ui->lineY2->text().toFloat()); // Передача введенных координиат в функцию виджета
}

MainWindow::~MainWindow()
{
    delete ui;
}

